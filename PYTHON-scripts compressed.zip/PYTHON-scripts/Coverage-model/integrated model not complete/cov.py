import re
import os
import time
import csv

#------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
#                                                   Ashwin Pradeep coverage
#------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


ashwinpradeep_mul_count=0
ashwinpradeep_dm_count=0
ashwinpradeep_byp_mul_count=0
ashwinpradeep_byp_dm_count=0
    
ashwinpradeep_results = { 

        # Rn = Rx * Ry
        'R0 = Rx * Ry':0, 
        'R1 = Rx * Ry':0, 
        'R2 = Rx * Ry':0, 
        'R3 = Rx * Ry':0, 
        'R4 = Rx * Ry':0, 
        'R5 = Rx * Ry':0, 
        'R6 = Rx * Ry':0, 
        'R7 = Rx * Ry':0, 
        'R8 = Rx * Ry':0, 
        'R9 = Rx * Ry':0, 
        'R10 = Rx * Ry':0, 
        'R11 = Rx * Ry':0, 
        'R12 = Rx * Ry':0, 
        'R13 = Rx * Ry':0, 
        'R14 = Rx * Ry':0, 
        'R15 = Rx * Ry':0, 
        
        'Rn = R0 * Ry':0, 
        'Rn = R1 * Ry':0, 
        'Rn = R2 * Ry':0, 
        'Rn = R3 * Ry':0, 
        'Rn = R4 * Ry':0, 
        'Rn = R5 * Ry':0, 
        'Rn = R6 * Ry':0, 
        'Rn = R7 * Ry':0, 
        'Rn = R8 * Ry':0, 
        'Rn = R9 * Ry':0, 
        'Rn = R10 * Ry':0, 
        'Rn = R11 * Ry':0, 
        'Rn = R12 * Ry':0, 
        'Rn = R13 * Ry':0, 
        'Rn = R14 * Ry':0, 
        'Rn = R15 * Ry':0, 
        
        'Rn = Rx * R0':0, 
        'Rn = Rx * R1':0, 
        'Rn = Rx * R2':0, 
        'Rn = Rx * R3':0, 
        'Rn = Rx * R4':0, 
        'Rn = Rx * R5':0, 
        'Rn = Rx * R6':0, 
        'Rn = Rx * R7':0, 
        'Rn = Rx * R8':0, 
        'Rn = Rx * R9':0, 
        'Rn = Rx * R10':0, 
        'Rn = Rx * R11':0, 
        'Rn = Rx * R12':0, 
        'Rn = Rx * R13':0, 
        'Rn = Rx * R14':0, 
        'Rn = Rx * R15':0, 

        # MR = Rx * Ry 
        'MR = R0 * Ry': 0, 'MR = R1 * Ry': 0, 'MR = R2 * Ry': 0, 'MR = R3 * Ry': 0, 'MR = R4 * Ry': 0, 'MR = R5 * Ry': 0, 'MR = R6 * Ry': 0, 'MR = R7 * Ry': 0, 'MR = R8 * Ry': 0, 'MR = R9 * Ry': 0, 'MR = R10 * Ry': 0, 'MR = R11 * Ry': 0, 'MR = R12 * Ry': 0, 'MR = R13 * Ry': 0, 'MR = R14 * Ry': 0, 'MR = R15 * Ry': 0,

        'MR = Rx * R0': 0, 'MR = Rx * R1': 0, 'MR = Rx * R2': 0, 'MR = Rx * R3': 0, 'MR = Rx * R4': 0, 'MR = Rx * R5': 0, 'MR = Rx * R6': 0, 'MR = Rx * R7': 0, 'MR = Rx * R8': 0, 'MR = Rx * R9': 0, 'MR = Rx * R10': 0, 'MR = Rx * R11': 0, 'MR = Rx * R12': 0, 'MR = Rx * R13': 0, 'MR = Rx * R14': 0, 'MR = Rx * R15': 0,


        # Rn = MR + Rx * Ry
        'R0 = MR + Rx * Ry':0, 
        'R1 = MR + Rx * Ry':0, 
        'R2 = MR + Rx * Ry':0, 
        'R3 = MR + Rx * Ry':0, 
        'R4 = MR + Rx * Ry':0, 
        'R5 = MR + Rx * Ry':0, 
        'R6 = MR + Rx * Ry':0, 
        'R7 = MR + Rx * Ry':0, 
        'R8 = MR + Rx * Ry':0, 
        'R9 = MR + Rx * Ry':0, 
        'R10 = MR + Rx * Ry':0, 
        'R11 = MR + Rx * Ry':0, 
        'R12 = MR + Rx * Ry':0, 
        'R13 = MR + Rx * Ry':0, 
        'R14 = MR + Rx * Ry':0, 
        'R15 = MR + Rx * Ry':0, 
        
        'Rn = MR + R0 * Ry':0, 
        'Rn = MR + R1 * Ry':0, 
        'Rn = MR + R2 * Ry':0, 
        'Rn = MR + R3 * Ry':0, 
        'Rn = MR + R4 * Ry':0, 
        'Rn = MR + R5 * Ry':0, 
        'Rn = MR + R6 * Ry':0, 
        'Rn = MR + R7 * Ry':0, 
        'Rn = MR + R8 * Ry':0, 
        'Rn = MR + R9 * Ry':0, 
        'Rn = MR + R10 * Ry':0, 
        'Rn = MR + R11 * Ry':0, 
        'Rn = MR + R12 * Ry':0, 
        'Rn = MR + R13 * Ry':0, 
        'Rn = MR + R14 * Ry':0, 
        'Rn = MR + R15 * Ry':0, 
        
        'Rn = MR + Rx * R0':0, 
        'Rn = MR + Rx * R1':0, 
        'Rn = MR + Rx * R2':0, 
        'Rn = MR + Rx * R3':0, 
        'Rn = MR + Rx * R4':0, 
        'Rn = MR + Rx * R5':0, 
        'Rn = MR + Rx * R6':0, 
        'Rn = MR + Rx * R7':0, 
        'Rn = MR + Rx * R8':0, 
        'Rn = MR + Rx * R9':0, 
        'Rn = MR + Rx * R10':0, 
        'Rn = MR + Rx * R11':0, 
        'Rn = MR + Rx * R12':0, 
        'Rn = MR + Rx * R13':0, 
        'Rn = MR + Rx * R14':0, 
        'Rn = MR + Rx * R15':0, 
        
        # Rn = MR - Rx * Ry
        'R0 = MR - Rx * Ry': 0, 'R1 = MR - Rx * Ry': 0, 'R2 = MR - Rx * Ry': 0, 'R3 = MR - Rx * Ry': 0, 'R4 = MR - Rx * Ry': 0, 'R5 = MR - Rx * Ry': 0, 'R6 = MR - Rx * Ry': 0, 'R7 = MR - Rx * Ry': 0, 'R8 = MR - Rx * Ry': 0, 'R9 = MR - Rx * Ry': 0, 'R10 = MR - Rx * Ry': 0, 'R11 = MR - Rx * Ry': 0, 'R12 = MR - Rx * Ry': 0, 'R13 = MR - Rx * Ry': 0, 'R14 = MR - Rx * Ry': 0, 'R15 = MR - Rx * Ry': 0,
        
        'Rn = MR - R0 * Ry': 0, 'Rn = MR - R1 * Ry': 0, 'Rn = MR - R2 * Ry': 0, 'Rn = MR - R3 * Ry': 0, 'Rn = MR - R4 * Ry': 0, 'Rn = MR - R5 * Ry': 0, 'Rn = MR - R6 * Ry': 0, 'Rn = MR - R7 * Ry': 0, 'Rn = MR - R8 * Ry': 0, 'Rn = MR - R9 * Ry': 0, 'Rn = MR - R10 * Ry': 0, 'Rn = MR - R11 * Ry': 0, 'Rn = MR - R12 * Ry': 0, 'Rn = MR - R13 * Ry': 0, 'Rn = MR - R14 * Ry': 0, 'Rn = MR - R15 * Ry': 0,

        'Rn = MR - Rx * R0': 0, 'Rn = MR - Rx * R1': 0, 'Rn = MR - Rx * R2': 0, 'Rn = MR - Rx * R3': 0, 'Rn = MR - Rx * R4': 0, 'Rn = MR - Rx * R5': 0, 'Rn = MR - Rx * R6': 0, 'Rn = MR - Rx * R7': 0, 'Rn = MR - Rx * R8': 0, 'Rn = MR - Rx * R9': 0, 'Rn = MR - Rx * R10': 0, 'Rn = MR - Rx * R11': 0, 'Rn = MR - Rx * R12': 0, 'Rn = MR - Rx * R13': 0, 'Rn = MR - Rx * R14': 0, 'Rn = MR - Rx * R15': 0,

        # MR = MR + Rx * Ry
        'MR = MR + R0 * Ry': 0, 'MR = MR + R1 * Ry': 0, 'MR = MR + R2 * Ry': 0, 'MR = MR + R3 * Ry': 0, 'MR = MR + R4 * Ry': 0, 'MR = MR + R5 * Ry': 0, 'MR = MR + R6 * Ry': 0, 'MR = MR + R7 * Ry': 0, 'MR = MR + R8 * Ry': 0, 'MR = MR + R9 * Ry': 0, 'MR = MR + R10 * Ry': 0, 'MR = MR + R11 * Ry': 0, 'MR = MR + R12 * Ry': 0, 'MR = MR + R13 * Ry': 0, 'MR = MR + R14 * Ry': 0, 'MR = MR + R15 * Ry': 0,

        'MR = MR + Rx * R0': 0, 'MR = MR + Rx * R1': 0, 'MR = MR + Rx * R2': 0, 'MR = MR + Rx * R3': 0, 'MR = MR + Rx * R4': 0, 'MR = MR + Rx * R5': 0, 'MR = MR + Rx * R6': 0, 'MR = MR + Rx * R7': 0, 'MR = MR + Rx * R8': 0, 'MR = MR + Rx * R9': 0, 'MR = MR + Rx * R10': 0, 'MR = MR + Rx * R11': 0, 'MR = MR + Rx * R12': 0, 'MR = MR + Rx * R13': 0, 'MR = MR + Rx * R14': 0, 'MR = MR + Rx * R15': 0,

        # MR = MR - Rx * Ry
        'MR = MR - R0 * Ry': 0, 'MR = MR - R1 * Ry': 0, 'MR = MR - R2 * Ry': 0, 'MR = MR - R3 * Ry': 0, 'MR = MR - R4 * Ry': 0, 'MR = MR - R5 * Ry': 0, 'MR = MR - R6 * Ry': 0, 'MR = MR - R7 * Ry': 0, 'MR = MR - R8 * Ry': 0, 'MR = MR - R9 * Ry': 0, 'MR = MR - R10 * Ry': 0, 'MR = MR - R11 * Ry': 0, 'MR = MR - R12 * Ry': 0, 'MR = MR - R13 * Ry': 0, 'MR = MR - R14 * Ry': 0, 'MR = MR - R15 * Ry': 0,

        'MR = MR - Rx * R0': 0, 'MR = MR - Rx * R1': 0, 'MR = MR - Rx * R2': 0, 'MR = MR - Rx * R3': 0, 'MR = MR - Rx * R4': 0, 'MR = MR - Rx * R5': 0, 'MR = MR - Rx * R6': 0, 'MR = MR - Rx * R7': 0, 'MR = MR - Rx * R8': 0, 'MR = MR - Rx * R9': 0, 'MR = MR - Rx * R10': 0, 'MR = MR - Rx * R11': 0, 'MR = MR - Rx * R12': 0, 'MR = MR - Rx * R13': 0, 'MR = MR - Rx * R14': 0, 'MR = MR - Rx * R15': 0,
        
        # Rn = MRx
        'R0 = MRx': 0, 'R1 = MRx': 0, 'R2 = MRx': 0, 'R3 = MRx': 0, 'R4 = MRx': 0, 'R5 = MRx': 0, 'R6 = MRx': 0, 'R7 = MRx': 0, 'R8 = MRx': 0, 'R9 = MRx': 0, 'R10 = MRx': 0, 'R11 = MRx': 0, 'R12 = MRx': 0, 'R13 = MRx': 0, 'R14 = MRx': 0, 'R15 = MRx': 0,

        'Rn = MR0':0, 'Rn = MR1':0, 'Rn = MR2':0,

        # MRx = Rn
        'MR0 = Rn':0, 'MR1 = Rn':0, 'MR2 = Rn':0,

        'MRx = R0': 0, 'MRx = R1': 0, 'MRx = R2': 0, 'MRx = R3': 0, 'MRx = R4': 0, 'MRx = R5': 0, 'MRx = R6': 0, 'MRx = R7': 0, 'MRx = R8': 0, 'MRx = R9': 0, 'MRx = R10': 0, 'MRx = R11': 0, 'MRx = R12': 0, 'MRx = R13': 0, 'MRx = R14': 0, 'MRx = R15': 0,
        
        # Rn = SAT MR
        'R0 = SAT MR': 0, 'R1 = SAT MR': 0, 'R2 = SAT MR': 0, 'R3 = SAT MR': 0, 'R4 = SAT MR': 0, 'R5 = SAT MR': 0, 'R6 = SAT MR': 0, 'R7 = SAT MR': 0, 'R8 = SAT MR': 0, 'R9 = SAT MR': 0, 'R10 = SAT MR': 0, 'R11 = SAT MR': 0, 'R12 = SAT MR': 0, 'R13 = SAT MR': 0, 'R14 = SAT MR': 0, 'R15 = SAT MR': 0,

        # TOTAL
        'Rn = Rx * Ry':0, 'MR = Rx * Ry':0, 'Rn = MR + Rx * Ry':0, 'MR = MR + Rx * Ry':0, 'Rn = MR - Rx * Ry':0, 'MR = MR - Rx * Ry':0, 'Rn = MRx':0, 'MRx = Rn':0, 'Rn = SAT MR':0, 'MR = SAT MR':0, 

        # data statuses
        'uui':0, 'uuf':0, 'uufr':0, 'sui':0, 'suf':0, 'sufr':0, 'usi':0, 'usf':0, 'usfr':0, 'ssi':0, 'ssf':0, 'ssfr':0, 

        # DM read and writes
        'DM writes':0, 'DM reads':0, 
        
        # Bypasses
        'DM->DM bypasses':0, 'ALU->DM bypasses':0, 'SHF->DM bypasses':0, 'MUL->DM bypasses':0, 'Immediate->DM bypasses':0, 'UREG->DM bypasses':0,
        
        'DM->MUL bypasses':0, 'ALU->MUL bypasses':0, 'SHF->MUL bypasses':0, 'MUL->MUL bypasses':0, 'Immediate->MUL bypasses':0, 'UREG->MUL bypasses':0,
        
        # Register read and writes summary
        'R0 reads':0, 
        'R1 reads':0, 
        'R2 reads':0, 
        'R3 reads':0, 
        'R4 reads':0, 
        'R5 reads':0, 
        'R6 reads':0, 
        'R7 reads':0, 
        'R8 reads':0, 
        'R9 reads':0, 
        'R10 reads':0, 
        'R11 reads':0, 
        'R12 reads':0, 
        'R13 reads':0, 
        'R14 reads':0, 
        'R15 reads':0, 
        'R0 writes':0,
        'R1 writes':0,
        'R2 writes':0,
        'R3 writes':0,
        'R4 writes':0,
        'R5 writes':0,
        'R6 writes':0,
        'R7 writes':0,
        'R8 writes':0,
        'R9 writes':0,
        'R10 writes':0,
        'R11 writes':0,
        'R12 writes':0,
        'R13 writes':0,
        'R14 writes':0,
        'R15 writes':0
        }

def ashwinpradeep_inst_id(ins):           # function to identify all possible mul instructions and dm instructions
    global ashwinpradeep_results
    global ashwinpradeep_mul_count
    global ashwinpradeep_dm_count
    err=0
    rn_list=re.findall("R\d+",ins)
    for rx in rn_list:
        if(int(rx[1:])>15):
            err=1

    if(re.search("IR$",ins)):       # finding error instruction like round for integer
        err=2

    if(err==0):
        #Rn=Rx*Ry
        if(re.findall("R\d+[=]R\d+[*]R\d+[U,S][U,S]?[I,F][R]?$",ins)):
            ashwinpradeep_results['Rn = Rx * Ry']+=1          
            LHS=re.findall("R\d+",ins.split('=')[0].strip(' '))      # Rn in LHS detected
            RHS=re.findall("R\d+[*]R\d+",ins.split('=')[1].strip(' '))   # Rx*Ry in RHS
            if LHS :
                ashwinpradeep_results[LHS[0].strip(' ')+' = Rx * Ry']+=1
            if RHS :
                rhslist=RHS[0].strip(' ').split('*')
                ashwinpradeep_results['Rn = '+ rhslist[0] +' * Ry']+=1
                ashwinpradeep_results['Rn = Rx * '+ rhslist[1]]+=1


        #MR=Rx*Ry
        elif(re.findall("MR[=]R\d+[*]R\d+[U,S][U,S]?[I,F][R]?$",ins)):
            ashwinpradeep_results['MR = Rx * Ry']+=1        
            RHS=re.findall("R\d+[*]R\d+",ins.split('=')[1].strip(' '))   # Rx*Ry in RHS
            if RHS :
                rhslist=RHS[0].strip(' ').split('*')
                ashwinpradeep_results['MR = '+ rhslist[0] +' * Ry']+=1
                ashwinpradeep_results['MR = Rx * '+ rhslist[1]]+=1
            
        #Rn=MR+Rx*Ry
        elif(re.findall("R\d+[=]MR[+]R\d+[*]R\d+[U,S][U,S]?[I,F][R]?$",ins)):
            ashwinpradeep_results['Rn = MR + Rx * Ry']+=1      
            LHS=re.findall("R\d+",ins.split('=')[0].strip(' '))      # Rn in LHS detected
            RHS=re.findall("R\d+[*]R\d+",ins.split('=')[1].strip(' '))   # Rx*Ry in RHS
            if LHS :
                ashwinpradeep_results[LHS[0].strip(' ')+' = MR + Rx * Ry']+=1
            if RHS :
                rhslist=RHS[0].strip(' ').split('*')
                ashwinpradeep_results['Rn = MR + '+ rhslist[0] +' * Ry']+=1
                ashwinpradeep_results['Rn = MR + Rx * '+ rhslist[1]]+=1

        #Rn=MR-Rx*Ry
        elif(re.findall("R\d+[=]MR[-]R\d+[*]R\d+[U,S][U,S]?[I,F][R]?$",ins)):
            ashwinpradeep_results['Rn = MR - Rx * Ry']+=1      
            LHS=re.findall("R\d+",ins.split('=')[0].strip(' '))      # Rn in LHS detected
            RHS=re.findall("R\d+[*]R\d+",ins.split('=')[1].strip(' '))   # Rx*Ry in RHS
            if LHS :
                ashwinpradeep_results[LHS[0].strip(' ')+' = MR - Rx * Ry']+=1
            if RHS :
                rhslist=RHS[0].strip(' ').split('*')
                ashwinpradeep_results['Rn = MR - '+ rhslist[0] +' * Ry']+=1
                ashwinpradeep_results['Rn = MR - Rx * '+ rhslist[1]]+=1

        #MR=MR+Rx*Ry
        elif(re.findall("MR[=]MR[+]R\d+[*]R\d+[U,S][U,S]?[I,F][R]?$",ins)):
            ashwinpradeep_results['MR = MR + Rx * Ry']+=1      
            RHS=re.findall("R\d+[*]R\d+",ins.split('=')[1].strip(' '))   # Rx*Ry in RHS
            if RHS :
                rhslist=RHS[0].strip(' ').split('*')
                ashwinpradeep_results['MR = MR + '+ rhslist[0] +' * Ry']+=1
                ashwinpradeep_results['MR = MR + Rx * '+ rhslist[1]]+=1

        #MR=MR-Rx*Ry
        elif(re.findall("MR[=]MR[-]R\d+[*]R\d+[U,S][U,S]?[I,F][R]?$",ins)):
            ashwinpradeep_results['MR = MR - Rx * Ry']+=1 
            RHS=re.findall("R\d+[*]R\d+",ins.split('=')[1].strip(' '))   # Rx*Ry in RHS
            if RHS :
                rhslist=RHS[0].strip(' ').split('*')
                ashwinpradeep_results['MR = MR - '+ rhslist[0] +' * Ry']+=1
                ashwinpradeep_results['MR = MR - Rx * '+ rhslist[1]]+=1

        #Rn=MRx
        elif(re.findall("R\d+[=]MR[0-2]$",ins)):
            ashwinpradeep_results['Rn = MRx']+=1     
            LHS=re.findall("R\d+",ins.split('=')[0].strip(' '))      # Rn in LHS detected
            RHS=re.findall("MR[0-2]",ins.split('=')[1].strip(' '))      # MRx in RHS detected
            if LHS :
                ashwinpradeep_results[LHS[0].strip(' ')+' = MRx']+=1
            if RHS :
                ashwinpradeep_results['Rn = '+RHS[0].strip(' ')]+=1

        #MRx=Rn
        elif(re.findall("MR[0-2][=]R\d+$",ins)):
            ashwinpradeep_results['MRx = Rn']+=1  
            LHS=re.findall("MR[0-2]",ins.split('=')[0].strip(' '))      # MRx in LHS detected
            RHS=re.findall("R\d+",ins.split('=')[1].strip(' '))      # Rn in RHS detected
            if LHS :
                ashwinpradeep_results[LHS[0].strip(' ')+' = Rn']+=1
            if RHS :
                ashwinpradeep_results['MRx = '+RHS[0].strip(' ')]+=1
        
        #Rn=SAT MR
        elif(re.findall("R\d+[=]SATMR[U,S][I,F]$",ins)):
            ashwinpradeep_results['Rn = SAT MR']+=1
            LHS=re.findall("R\d+",ins.split('=')[0].strip(' '))      # Rn in LHS detected
            if LHS :
                ashwinpradeep_results[LHS[0].strip(' ')+' = SAT MR']+=1
            
        #MR=SAT MR
        elif(re.findall("MR=SATMR[U,S][I,F]$",ins)):
            ashwinpradeep_results['MR = SAT MR']+=1    

        else:
            ashwinpradeep_mul_count-=1    # not a mul instruction 
            if(re.findall("^DM[(]I[0-8][,]M[0-8][)]=",ins)):
                ashwinpradeep_results['DM writes']+=1
                ashwinpradeep_dm_count+=1
            elif(re.findall("=DM[(]I[0-8][,]M[0-8][)]$",ins)):
                ashwinpradeep_results['DM reads']+=1
                ashwinpradeep_dm_count+=1

        if(re.findall("UUI$",ins)):
            ashwinpradeep_results['uui']+=1
        elif(re.findall("UUF$",ins)):
            ashwinpradeep_results['uuf']+=1
        elif(re.findall("UUFR$",ins)):
            ashwinpradeep_results['uufr']+=1
        elif(re.findall("SUI$",ins)):
            ashwinpradeep_results['sui']+=1
        elif(re.findall("SUF$",ins)):
            ashwinpradeep_results['suf']+=1
        elif(re.findall("SUFR$",ins)):
            ashwinpradeep_results['sufr']+=1
        elif(re.findall("USI$",ins)):
            ashwinpradeep_results['usi']+=1
        elif(re.findall("USF$",ins)):
            ashwinpradeep_results['usf']+=1
        elif(re.findall("USFR$",ins)):
            ashwinpradeep_results['usfr']+=1
        elif(re.findall("SSI$",ins)):
            ashwinpradeep_results['ssi']+=1
        elif(re.findall("SSF$",ins)):
            ashwinpradeep_results['ssf']+=1
        elif(re.findall("SSFR$",ins)):
            ashwinpradeep_results['ssfr']+=1
        
    elif(err==1):
        ashwinpradeep_mul_count-=1        # Reg address surpassed bounds
    else:
        ashwinpradeep_mul_count-=1        # Invalid instruction


instype = {1:'mul', 2:'shf', 3:'alu', 4:'dm', 5:'ureg'}     #used to detect what type of instruction is used

def ashwinpradeep_instype_detector(ref):          # broadly identifies type of instruction
    if '*' in ref or 'MR' in ref :
        return 1
    elif 'BY' in ref or 'LEFT' in ref :
        return 2
    elif "+" in ref or '-' in ref or 'MIN' in ref or 'MAX' in ref or 'COMP' in ref or 'OR' in ref or 'AND' in ref or 'ABS' in ref or 'NOT' in ref :
        return 3
    elif 'DM' in ref :
        return 4
    else :
        return 5

def ashwinpradeep_Rn_readwrite_detector(ins):
    ins=re.sub("\s+"," ",ins)
    if '=' in ins :
        LHS=re.findall("[ ]R\d+",' '+ins.split('=')[0].strip(' '))      # Rn in LHS detected
        RHS=re.findall("R\d+[*]R\d+",' '+ins.split('=')[1].strip(' ')) if re.findall("R\d+[*]R\d+",' '+ins.split('=')[1].strip(' ')) else re.findall("[ ]R\d+",' '+ins.split('=')[1].strip(' '))
        if LHS :
            ashwinpradeep_results[LHS[0].strip(' ')+' writes']+=1
        if RHS :
            rhslist=RHS[0].strip(' ').split('*')
            for r in rhslist:
                ashwinpradeep_results[r+' reads']+=1
        #if LHS :
        #    print('\n',LHS[0].strip(' '),end='=')
        #if RHS :
        #    print(RHS[0].strip(' ').split('*'))


def ashwinpradeep_byp_detector(ins,ref,f):            # detects type of bypass src-destn bypass; destn={mul or dm}
    ins=re.sub("\s+"," ",ins)
    ref=re.sub("\s+"," ",ref)
    n=re.findall("R\d+",ins)
    flag=False
    for i in n :
        if int(i.split('R')[1])>15:
            print(f,' Error : ',ins)
            flag=True
    if flag:
        return
    if '=' in ins and '=' in ref :          # bypass detected only for '=' instructions
        destn = ' ' + ref.split('=')[0].strip(' ')
        read = ' ' + ins.split('=')[1]
        d = re.findall("[ ]R\d+",destn)         # d=[' Rn'] we detect destination as some register
        r = []                                  # r will be used to store the read registers
        if re.findall("R\d+[*]R\d+",read):      # = Rx * Ry
            r = re.findall("R\d+[*]R\d+",read)      # r=['Rx*Ry']
        elif re.findall("[ ]R\d+",read):        # = Rn
            r = re.findall("[ ]R\d+",read)          # r=[' Rn']
        if d and r :
            if d[0].strip(' ') in r[0].strip(' ').split('*') :  # LHS of (n-1)th ins in RHS of nth ins .ie. bypass detected
                #print(ins,' : ',f)
                if ashwinpradeep_instype_detector(ins)==1 :
                    if ashwinpradeep_instype_detector(ref)==4 :           # DM-mul bypass data if ref instruction is dm instruction
                        ashwinpradeep_results['DM->MUL bypasses']+=1
                        #print(ins,'<-',ref,'DM-MUL bypass')
                
                    elif ashwinpradeep_instype_detector(ref)==1 :         # Mul-mul bypass data
                        ashwinpradeep_results['MUL->MUL bypasses']+=1
                        #print(ins,'<-',ref,'MUL-MUL bypass')
                
                    elif ashwinpradeep_instype_detector(ref)==3 :         # Alu-mul bypass data
                        ashwinpradeep_results['ALU->MUL bypasses']+=1
                        #print(ins,'<-',ref,'ALU-MUL bypass')

                    elif ashwinpradeep_instype_detector(ref)==2 :          # Shf-mul bypass data
                        ashwinpradeep_results['SHF->MUL bypasses']+=1
                        #print(ins,'<-',ref,'SHF-MUL bypass')

                    elif ashwinpradeep_instype_detector(ref)==5 :              # immdata-mul bypass data
                        ashwinpradeep_results['Immediate->MUL bypasses']+=1
                        #print(ins,'<-',ref,'Imm-MUL bypass')
                
                elif ashwinpradeep_instype_detector(ins)==4 :
                    if ashwinpradeep_instype_detector(ref)==4 :           # DM-dm bypass data if ref instruction is dm instruction
                        ashwinpradeep_results['DM->DM bypasses']+=1
                        #print(ins,'<-',ref,'DM-DM bypass')
                
                    elif ashwinpradeep_instype_detector(ref)==1 :         # Mul-dm bypass data
                        ashwinpradeep_results['MUL->DM bypasses']+=1
                        #print(ins,'<-',ref,'MUL-DM bypass')
                
                    elif ashwinpradeep_instype_detector(ref)==3 :         # Alu-dm bypass data
                        ashwinpradeep_results['ALU->DM bypasses']+=1
                        #print(ins,'<-',ref,'ALU-DM bypass')

                    elif ashwinpradeep_instype_detector(ref)==2 :          # Shf-dm bypass data
                        ashwinpradeep_results['SHF->DM bypasses']+=1
                        #print(ins,'<-',ref,'SHF-DM bypass')

                    elif ashwinpradeep_instype_detector(ref)==5 :              # immdata-dm bypass data
                        ashwinpradeep_results['Immediate->DM bypasses']+=1
                        #print(ins,'<-',ref,'Imm-DM bypass')
                '''
                if re.findall("DM",ins.split('=')[0].strip(' ')) :
                    ashwinpradeep_results['RF->DM bypasses']+=1
                else:
                    ashwinpradeep_results['RF->MUL bypasses']+=1
                '''

def ashwinpradeep_main(path):
    #path=input("Enter path to directory containing instruction files : ")
    folder_list=os.listdir(path)
    global ashwinpradeep_mul_count
    global ashwinpradeep_dm_count
    global ashwinpradeep_byp_mul_count
    global ashwinpradeep_byp_dm_count
    c=0

    for folder in folder_list:
        files_list=os.listdir(path+'\\'+folder)
        for f in files_list:
            fi=open(path+"\\"+folder+"\\"+f,'r')
            ins_list=fi.readlines()
            for i in range(1,len(ins_list)):
                ins=ins_list[i].strip('\n').split('#')[0].upper()
                ref_ins=ins_list[i-1].strip('\n').split('#')[0].upper()     # ref ins for bypass checking
                ashwinpradeep_mul_count+=1
                inst=re.sub("\s*","",ins)
                ashwinpradeep_inst_id(inst)
                ashwinpradeep_byp_detector(ins,ref_ins,f)
                ashwinpradeep_Rn_readwrite_detector(ins)
                #ashwinpradeep_byp_mul_count=ashwinpradeep_results['RF->MUL bypasses']
                #ashwinpradeep_byp_dm_count=ashwinpradeep_results['RF->DM bypasses']
                c+=1
                if ref_ins.strip(' ').lower()=='finish' or ins.strip(' ').lower()=='finish':
                    break
            fi.close()

    print('='*50)
    print('\nAshwin coverage')
    print("Number of multiplier instructions = ",ashwinpradeep_mul_count)
    print("Number of dm access instructions = ",ashwinpradeep_dm_count)
    print("Total = ",c)
    #print("Number of RF bypasses for multiplier instructions = ",ashwinpradeep_byp_mul_count)
    #print("Number of RF bypasses for DM instructions = ",ashwinpradeep_byp_dm_count)

    with open("ashwinpradeep_coverage.csv","w",newline='') as csvF:
        wobj=csv.writer(csvF,delimiter=',')
        wobj.writerow(['Instructions','Count'])
        for ins in ashwinpradeep_results.keys():
            #print(ins,'|',ashwinpradeep_results[ins])
            wobj.writerow([ins,ashwinpradeep_results[ins]])


#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
#                                               Raman coverage
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

raman_i=0
raman_m=0
raman_j=0
raman_x=0
raman_y=0
raman_z=0
raman_types = { 'NOP':0, 'IDLE':0, 'FINISH':0, 'DM = UREG':0, 'UREG = DM':0, 'UREG = UREG':0, 'MODIFY(I,M)':0, 'JUMP(M,I)':0, 'RTS':0, 'CALL(M,I)':0, 'PUSH PCSTK = UREG':0, 'UREG = POP PCSTK':0,
        'UREG = immediate data':0, 'EQ':0, 'NE':0, 'LE':0, 'LT':0, 'GE':0, 'GT':0, 'AC':0, 'NOT_AC':0, 'AV':0, 'NOT_AV':0, 'MV':0, 'NOT_MV':0, 'MS':0, 'NOT_MS':0, 'SV':0, 'NOT_SV':0, 'SZ':0,
        'NOT_SZ':0, 'FOREVER':0, 'UREG reads':0, 'UREG writes':0, 'Bypasses':0, 'UREG to UREG bypasses':0, 'Sticky bypasses':0, 'PCSTK pointer bypasses':0, 'DM bypass':0, 'I to DM bypass':0, 'M to DM bypass':0,
        'ASTAT bypasses':0, 'ASTAT read':0, 'ASTAT write':0, 'MODE1 read':0, 'MODE1 write':0, 'PCSTK read':0,  'PCSTK write':0, 'FADDR read':0, 'DADDR read':0, 'STKY read':0, 'PC read':0,
        'PCSTKP read':0, 
        'R0 read':0, 'R1 read':0, 'R2 read':0, 'R3 read':0, 'R4 read':0, 'R5 read':0, 'R6 read':0, 'R7 read':0, 'R8 read':0, 'R9 read':0, 'R10 read':0, 'R11 read':0,
        'R12 read':0, 'R13 read':0, 'R14 read':0, 'R15 read':0, 'R0 write':0, 'R1 write':0, 'R2 write':0, 'R3 write':0, 'R4 write':0, 'R5 write':0, 'R6 write':0, 'R7 write':0, 'R8 write':0,
        'R9 write':0, 'R10 write':0, 'R11 write':0,'R12 write':0, 'R13 write':0, 'R14 write':0, 'R15 write':0, 
        'I0 read':0, 'I1 read':0, 'I2 read':0, 'I3 read':0, 'I4 read':0, 'I5 read':0,
        'I6 read':0, 'I7 read':0, 'I8 read':0, 'I9 read':0, 'I10 read':0, 'I11 read':0, 'I12 read':0, 'I13 read':0, 'I14 read':0, 'I15 read':0, 'I0 write':0, 'I1 write':0, 'I2 write':0,
        'I3 write':0, 'I4 write':0, 'I5 write':0, 'I6 write':0, 'I7 write':0, 'I8 write':0, 'I9 write':0, 'I10 write':0, 'I11 write':0,'I12 write':0, 'I13 write':0, 'I14 write':0, 'I15 write':0,
        'M0 read':0, 'M1 read':0, 'M2 read':0, 'M3 read':0, 'M4 read':0, 'M5 read':0, 'M6 read':0, 'M7 read':0, 'M8 read':0, 'M9 read':0, 'M10 read':0, 'M11 read':0, 'M12 read':0, 'M13 read':0,
        'M14 read':0, 'M15 read':0, 'M0 write':0, 'M1 write':0, 'M2 write':0, 'M3 write':0, 'M4 write':0, 'M5 write':0, 'M6 write':0, 'M7 write':0, 'M8 write':0, 'M9 write':0, 'M10 write':0,
        'M11 write':0,'M12 write':0, 'M13 write':0, 'M14 write':0, 'M15 write':0}

def raman_cov(ins):
    global raman_types
    global raman_i,raman_x,raman_y,raman_z,raman_m,raman_j,raman_z
    global temps1,temps2,temppc1,temppc2,tempcpt1,tempcpt2,temp1,tem1,tem2,tem3,tem4,tem5,tem6,tem7,tem8,temp1,temp2,temp11,temp22,temp3,temp4,te,ts,tp

    tem1=None
    tem2=None
    tem3=None
    tem4=None
    tem5=None
    tem6=None
    tem7=None
    tem8=None
    temp3=None
    temp22=None
    temp11=None
    temps1=None
    if(re.findall("MEMCHECK$",ins) or re.findall("^[0-9,A-F][0-9,A-F][0-9,A-F][0-9,A-F]",ins) or re.findall("^#",ins)):
        raman_j+=1
    else:
        if(re.findall("^RTS$",ins)):
            raman_types['RTS']+=1
        elif(re.findall("DM[ ]?[(][ ]?I[0-7][ ]?,[ ]?M[0-7][ ]?[)][ ]?=[ ]?[R,I,M][0-9]+[ ]?$",ins)):
            raman_types['DM = UREG']+=1
        elif(re.findall("DM[ ]?[(][ ]?I[0-7][ ]?,[ ]?M[0-7][ ]?[)][ ]?=[ ]?ASTAT[ ]?$",ins)):
            raman_types['DM = UREG']+=1
        elif(re.findall("DM[ ]?[(][ ]?I[0-7][ ]?,[ ]?M[0-7][ ]?[)][ ]?=[ ]?MODE1[ ]?$",ins)):
            raman_types['DM = UREG']+=1
        elif(re.findall("DM[ ]?[(][ ]?I[0-7][ ]?,[ ]?M[0-7][ ]?[)][ ]?=[ ]?PCSTK[ ]?$",ins)):
            raman_types['DM = UREG']+=1
        elif(re.findall("[R,I,M][0-9]+[ ]?=[ ]?DM[ ]?[(][ ]?I[0-7][ ]?,[ ]?M[0-7][ ]?[)][ ]?$",ins)):
            raman_types['UREG = DM']+=1
        elif(re.findall("ASTAT[ ]?=[ ]?DM[ ]?[(][ ]?I[0-7][ ]?,[ ]?M[0-7][ ]?[)][ ]?$",ins)):
            raman_types['UREG = DM']+=1
        elif(re.findall("PCSTK[ ]?=[ ]?DM[ ]?[(][ ]?I[0-7][ ]?,[ ]?M[0-7][ ]?[)][ ]?$",ins)):
            raman_types['UREG = DM']+=1
        elif(re.findall("MODE1[ ]?=[ ]?DM[ ]?[(][ ]?I[0-7][ ]?,[ ]?M[0-7][ ]?[)][ ]?$",ins)):
            raman_types['UREG = DM']+=1
        elif(re.findall("^PUSH",ins)):
            raman_types['PUSH PCSTK = UREG']+=1
        elif(re.findall("MODIFY[ ]?[(][ ]?I[0-7][ ]?,[ ]?M[0-7][ ]?[)][ ]?$",ins)):
            raman_types['MODIFY(I,M)']+=1
        elif(re.findall("[R,I,M]?[A]?[S]?[T]?[A]?[T]?[P]?[C]?[S]?[T]?[K]?[M]?[O]?[D]?[E]?[0-9]?[0-9]?[ ]?=[ ]?ASTAT[ ]?$",ins)):
            raman_types['UREG = UREG']+=1
        elif(re.findall("[R,I,M]?[A]?[S]?[T]?[A]?[T]?[P]?[C]?[S]?[T]?[K]?[M]?[O]?[D]?[E]?[0-9]?[0-9]?[ ]?=[ ]?MODE1[ ]?$",ins)):
            raman_types['UREG = UREG']+=1
        elif(re.findall("[R,I,M]?[A]?[S]?[T]?[A]?[T]?[P]?[C]?[S]?[T]?[K]?[M]?[O]?[D]?[E]?[0-9]?[0-9]?[ ]?=[ ]?PCSTK[ ]?$",ins)):
            raman_types['UREG = UREG']+=1
        elif(re.match("^ASTAT[ ]?=[ ]?[R,I,M][0-9]+[ ]?$",ins)):
            raman_types['UREG = UREG']+=1
        elif(re.match("^MODE1[ ]?=[ ]?[R,I,M][0-9]+[ ]?$",ins)):
            raman_types['UREG = UREG']+=1
        elif(re.match("^PCSTK[ ]?=[ ]?[R,I,M][0-9]+[ ]?$",ins)):
            raman_types['UREG = UREG']+=1
        elif(re.match("^[R,I,M][0-9]+[ ]?=[ ]?[R,I,M][0-9]+[ ]?$",ins)):
            raman_types['UREG = UREG']+=1
        elif(re.match("^IF[ ]?NOT[ ]?AV[ ]?[R,I,M][0-9]+[ ]?=[ ]?[R,I,M][0-9]+[ ]?$",ins)):
            raman_types['UREG = UREG']+=1
        elif(re.match("^IF[ ]?NOT[ ]?AV[ ]?ASTAT[ ]?=[ ]?[R,I,M][0-9]+[ ]?$",ins)):
            raman_types['UREG = UREG']+=1
        elif(re.match("^IF[ ]?NOT[ ]?AV[ ]?MODE1[ ]?=[ ]?[R,I,M][0-9]+[ ]?$",ins)):
            raman_types['UREG = UREG']+=1
        elif(re.match("^IF[ ]?NOT[ ]?AV[ ]?PCSTK[ ]?=[ ]?[R,I,M][0-9]+[ ]?$",ins)):
            raman_types['UREG = UREG']+=1
        elif(re.match("^IF[ ]?NOT[ ]?MV[ ]?[R,I,M][0-9]+[ ]?=[ ]?[R,I,M][0-9]+[ ]?$",ins)):
            raman_types['UREG = UREG']+=1
        elif(re.match("^IF[ ]?NOT[ ]?MV[ ]?ASTAT[ ]?=[ ]?[R,I,M][0-9]+[ ]?$",ins)):
            raman_types['UREG = UREG']+=1
        elif(re.match("^IF[ ]?NOT[ ]?MV[ ]?MODE1[ ]?=[ ]?[R,I,M][0-9]+[ ]?$",ins)):
            raman_types['UREG = UREG']+=1
        elif(re.match("^IF[ ]?NOT[ ]?MV[ ]?PCSTK[ ]?=[ ]?[R,I,M][0-9]+[ ]?$",ins)):
            raman_types['UREG = UREG']+=1
        elif(re.match("^IF[ ]?NOT[ ]?SV[ ]?[R,I,M][0-9]+[ ]?=[ ]?[R,I,M][0-9]+[ ]?$",ins)):
            raman_types['UREG = UREG']+=1
        elif(re.match("^IF[ ]?NOT[ ]?SV[ ]?ASTAT[ ]?=[ ]?[R,I,M][0-9]+[ ]?$",ins)):
            raman_types['UREG = UREG']+=1
        elif(re.match("^IF[ ]?NOT[ ]?SV[ ]?MODE1[ ]?=[ ]?[R,I,M][0-9]+[ ]?$",ins)):
            raman_types['UREG = UREG']+=1
        elif(re.match("^IF[ ]?NOT[ ]?SV[ ]?PCSTK[ ]?=[ ]?[R,I,M][0-9]+[ ]?$",ins)):
            raman_types['UREG = UREG']+=1
        elif(re.match("^IF[ ]?NOT[ ]?SZ[ ]?[R,I,M][0-9]+[ ]?=[ ]?[R,I,M][0-9]+[ ]?$",ins)):
            raman_types['UREG = UREG']+=1
        elif(re.match("^IF[ ]?NOT[ ]?SZ[ ]?ASTAT[ ]?=[ ]?[R,I,M][0-9]+[ ]?$",ins)):
            raman_types['UREG = UREG']+=1
        elif(re.match("^IF[ ]?NOT[ ]?SZ[ ]?MODE1[ ]?=[ ]?[R,I,M][0-9]+[ ]?$",ins)):
            raman_types['UREG = UREG']+=1
        elif(re.match("^IF[ ]?NOT[ ]?SZ[ ]?PCSTK[ ]?=[ ]?[R,I,M][0-9]+[ ]?$",ins)):
            raman_types['UREG = UREG']+=1
        elif(re.match("^IF[ ]?NOT[ ]?MS[ ]?[R,I,M][0-9]+[ ]?=[ ]?[R,I,M][0-9]+[ ]?$",ins)):
            raman_types['UREG = UREG']+=1
        elif(re.match("^IF[ ]?NOT[ ]?MS[ ]?ASTAT[ ]?=[ ]?[R,I,M][0-9]+[ ]?$",ins)):
            raman_types['UREG = UREG']+=1
        elif(re.match("^IF[ ]?NOT[ ]?MS[ ]?MODE1[ ]?=[ ]?[R,I,M][0-9]+[ ]?$",ins)):
            raman_types['UREG = UREG']+=1
        elif(re.match("^IF[ ]?NOT[ ]?MS[ ]?PCSTK[ ]?=[ ]?[R,I,M][0-9]+[ ]?$",ins)):
            raman_types['UREG = UREG']+=1
        elif(re.match("^IF[ ]?NOT[ ]?AC[ ]?[R,I,M][0-9]+[ ]?=[ ]?[R,I,M][0-9]+[ ]?$",ins)):
            raman_types['UREG = UREG']+=1
        elif(re.match("^IF[ ]?NOT[ ]?AC[ ]?ASTAT[ ]?=[ ]?[R,I,M][0-9]+[ ]?$",ins)):
            raman_types['UREG = UREG']+=1
        elif(re.match("^IF[ ]?NOT[ ]?AC[ ]?MODE1[ ]?=[ ]?[R,I,M][0-9]+[ ]?$",ins)):
            raman_types['UREG = UREG']+=1
        elif(re.match("^IF[ ]?NOT[ ]?AC[ ]?PCSTK[ ]?=[ ]?[R,I,M][0-9]+[ ]?$",ins)):
            raman_types['UREG = UREG']+=1
        elif(re.match("^IF[ ]?AV[ ]?[R,I,M][0-9]+[ ]?=[ ]?[R,I,M][0-9]+[ ]?$",ins)):
            raman_types['UREG = UREG']+=1
        elif(re.match("^IF[ ]?AV[ ]?ASTAT[ ]?=[ ]?[R,I,M][0-9]+[ ]?$",ins)):
            raman_types['UREG = UREG']+=1
        elif(re.match("^IF[ ]?AV[ ]?MODE1[ ]?=[ ]?[R,I,M][0-9]+[ ]?$",ins)):
            raman_types['UREG = UREG']+=1
        elif(re.match("^IF[ ]?AV[ ]?PCSTK[ ]?=[ ]?[R,I,M][0-9]+[ ]?$",ins)):
            raman_types['UREG = UREG']+=1
        elif(re.match("^IF[ ]?AC[ ]?[R,I,M][0-9]+[ ]?=[ ]?[R,I,M][0-9]+[ ]?$",ins)):
            raman_types['UREG = UREG']+=1
        elif(re.match("^IF[ ]?AC[ ]?ASTAT[ ]?=[ ]?[R,I,M][0-9]+[ ]?$",ins)):
            raman_types['UREG = UREG']+=1
        elif(re.match("^IF[ ]?AC[ ]?MODE1[ ]?=[ ]?[R,I,M][0-9]+[ ]?$",ins)):
            raman_types['UREG = UREG']+=1
        elif(re.match("^IF[ ]?AC[ ]?PCSTK[ ]?=[ ]?[R,I,M][0-9]+[ ]?$",ins)):
            raman_types['UREG = UREG']+=1
        elif(re.match("^IF[ ]?MV[ ]?[R,I,M][0-9]+[ ]?=[ ]?[R,I,M][0-9]+[ ]?$",ins)):
            raman_types['UREG = UREG']+=1
        elif(re.match("^IF[ ]?MV[ ]?ASTAT[ ]?=[ ]?[R,I,M][0-9]+[ ]?$",ins)):
            raman_types['UREG = UREG']+=1
        elif(re.match("^IF[ ]?MV[ ]?MODE1[ ]?=[ ]?[R,I,M][0-9]+[ ]?$",ins)):
            raman_types['UREG = UREG']+=1
        elif(re.match("^IF[ ]?MV[ ]?PCSTK[ ]?=[ ]?[R,I,M][0-9]+[ ]?$",ins)):
            raman_types['UREG = UREG']+=1
        elif(re.match("^IF[ ]?SV[ ]?[R,I,M][0-9]+[ ]?=[ ]?[R,I,M][0-9]+[ ]?$",ins)):
            raman_types['UREG = UREG']+=1
        elif(re.match("^IF[ ]?SV[ ]?ASTAT[ ]?=[ ]?[R,I,M][0-9]+[ ]?$",ins)):
            raman_types['UREG = UREG']+=1
        elif(re.match("^IF[ ]?SV[ ]?MODE1[ ]?=[ ]?[R,I,M][0-9]+[ ]?$",ins)):
            raman_types['UREG = UREG']+=1
        elif(re.match("^IF[ ]?SV[ ]?PCSTK[ ]?=[ ]?[R,I,M][0-9]+[ ]?$",ins)):
            raman_types['UREG = UREG']+=1
        elif(re.match("^IF[ ]?MS[ ]?[R,I,M][0-9]+[ ]?=[ ]?[R,I,M][0-9]+[ ]?$",ins)):
            raman_types['UREG = UREG']+=1
        elif(re.match("^IF[ ]?MS[ ]?ASTAT[ ]?=[ ]?[R,I,M][0-9]+[ ]?$",ins)):
            raman_types['UREG = UREG']+=1
        elif(re.match("^IF[ ]?MS[ ]?MODE1[ ]?=[ ]?[R,I,M][0-9]+[ ]?$",ins)):
            raman_types['UREG = UREG']+=1
        elif(re.match("^IF[ ]?MS[ ]?PCSTK[ ]?=[ ]?[R,I,M][0-9]+[ ]?$",ins)):
            raman_types['UREG = UREG']+=1
        elif(re.match("^IF[ ]?SZ[ ]?[R,I,M][0-9]+[ ]?=[ ]?[R,I,M][0-9]+[ ]?$",ins)):
            raman_types['UREG = UREG']+=1
        elif(re.match("^IF[ ]?SZ[ ]?ASTAT[ ]?=[ ]?[R,I,M][0-9]+[ ]?$",ins)):
            raman_types['UREG = UREG']+=1
        elif(re.match("^IF[ ]?SZ[ ]?MODE1[ ]?=[ ]?[R,I,M][0-9]+[ ]?$",ins)):
            raman_types['UREG = UREG']+=1
        elif(re.match("^IF[ ]?SZ[ ]?PCSTK[ ]?=[ ]?[R,I,M][0-9]+[ ]?$",ins)):
            raman_types['UREG = UREG']+=1
        elif(re.match("^IF[ ]?NE[ ]?[R,I,M][0-9]+[ ]?=[ ]?[R,I,M][0-9]+[ ]?$",ins)):
            raman_types['UREG = UREG']+=1
        elif(re.match("^IF[ ]?NE[ ]?ASTAT[ ]?=[ ]?[R,I,M][0-9]+[ ]?$",ins)):
            raman_types['UREG = UREG']+=1
        elif(re.match("^IF[ ]?NE[ ]?MODE1[ ]?=[ ]?[R,I,M][0-9]+[ ]?$",ins)):
            raman_types['UREG = UREG']+=1
        elif(re.match("^IF[ ]?NE[ ]?PCSTK[ ]?=[ ]?[R,I,M][0-9]+[ ]?$",ins)):
            raman_types['UREG = UREG']+=1
        elif(re.match("^IF[ ]?EQ[ ]?[R,I,M][0-9]+[ ]?=[ ]?[R,I,M][0-9]+[ ]?$",ins)):
            raman_types['UREG = UREG']+=1
        elif(re.match("^IF[ ]?EQ[ ]?ASTAT[ ]?=[ ]?[R,I,M][0-9]+[ ]?$",ins)):
            raman_types['UREG = UREG']+=1
        elif(re.match("^IF[ ]?EQ[ ]?MODE1[ ]?=[ ]?[R,I,M][0-9]+[ ]?$",ins)):
            raman_types['UREG = UREG']+=1
        elif(re.match("^IF[ ]?EQ[ ]?PCSTK[ ]?=[ ]?[R,I,M][0-9]+[ ]?$",ins)):
            raman_types['UREG = UREG']+=1
        elif(re.match("^IF[ ]?LE[ ]?[R,I,M][0-9]+[ ]?=[ ]?[R,I,M][0-9]+[ ]?$",ins)):
            raman_types['UREG = UREG']+=1
        elif(re.match("^IF[ ]?LE[ ]?ASTAT[ ]?=[ ]?[R,I,M][0-9]+[ ]?$",ins)):
            raman_types['UREG = UREG']+=1
        elif(re.match("^IF[ ]?LE[ ]?MODE1[ ]?=[ ]?[R,I,M][0-9]+[ ]?$",ins)):
            raman_types['UREG = UREG']+=1
        elif(re.match("^IF[ ]?LE[ ]?PCSTK[ ]?=[ ]?[R,I,M][0-9]+[ ]?$",ins)):
            raman_types['UREG = UREG']+=1
        elif(re.match("^IF[ ]?LT[ ]?[R,I,M][0-9]+[ ]?=[ ]?[R,I,M][0-9]+[ ]?$",ins)):
            raman_types['UREG = UREG']+=1
        elif(re.match("^IF[ ]?LT[ ]?ASTAT[ ]?=[ ]?[R,I,M][0-9]+[ ]?$",ins)):
            raman_types['UREG = UREG']+=1
        elif(re.match("^IF[ ]?LT[ ]?MODE1[ ]?=[ ]?[R,I,M][0-9]+[ ]?$",ins)):
            raman_types['UREG = UREG']+=1
        elif(re.match("^IF[ ]?LT[ ]?PCSTK[ ]?=[ ]?[R,I,M][0-9]+[ ]?$",ins)):
            raman_types['UREG = UREG']+=1
        elif(re.match("^IF[ ]?GE[ ]?[R,I,M][0-9]+[ ]?=[ ]?[R,I,M][0-9]+[ ]?$",ins)):
            raman_types['UREG = UREG']+=1
        elif(re.match("^IF[ ]?GE[ ]?ASTAT[ ]?=[ ]?[R,I,M][0-9]+[ ]?$",ins)):
            raman_types['UREG = UREG']+=1
        elif(re.match("^IF[ ]?GE[ ]?MODE1[ ]?=[ ]?[R,I,M][0-9]+[ ]?$",ins)):
            raman_types['UREG = UREG']+=1
        elif(re.match("^IF[ ]?GE[ ]?PCSTK[ ]?=[ ]?[R,I,M][0-9]+[ ]?$",ins)):
            raman_types['UREG = UREG']+=1
        elif(re.match("^IF[ ]?GT[ ]?[R,I,M][0-9]+[ ]?=[ ]?[R,I,M][0-9]+[ ]?$",ins)):
            raman_types['UREG = UREG']+=1
        elif(re.match("^IF[ ]?GT[ ]?ASTAT[ ]?=[ ]?[R,I,M][0-9]+[ ]?$",ins)):
            raman_types['UREG = UREG']+=1
        elif(re.match("^IF[ ]?GT[ ]?MODE1[ ]?=[ ]?[R,I,M][0-9]+[ ]?$",ins)):
            raman_types['UREG = UREG']+=1
        elif(re.match("^IF[ ]?GT[ ]?PCSTK[ ]?=[ ]?[R,I,M][0-9]+[ ]?$",ins)):
            raman_types['UREG = UREG']+=1
        elif(re.match("^IF[ ]?FOREVER[ ]?[R,I,M][0-9]+[ ]?=[ ]?[R,I,M][0-9]+[ ]?$",ins)):
            raman_types['UREG = UREG']+=1
        elif(re.match("^IF[ ]?FOREVER[ ]?ASTAT[ ]?=[ ]?[R,I,M][0-9]+[ ]?$",ins)):
            raman_types['UREG = UREG']+=1
        elif(re.match("^IF[ ]?FOREVER[ ]?MODE1[ ]?=[ ]?[R,I,M][0-9]+[ ]?$",ins)):
            raman_types['UREG = UREG']+=1
        elif(re.match("^IF[ ]?FOREVER[ ]?PCSTK[ ]?=[ ]?[R,I,M][0-9]+[ ]?$",ins)):
            raman_types['UREG = UREG']+=1
        elif(re.findall("JUMP[ ]?[(][ ]?M[1,8,9][0-5]*[ ]?,[ ]?I[1,8,9][0-5]*[ ]?[)][ ]?$",ins)):
            raman_types['JUMP(M,I)']+=1
        elif(re.findall("CALL[ ]?[(][ ]?M[1,8,9][0-5]*[ ]?,[ ]?I[1,8,9][0-5]*[ ]?[)][ ]?$",ins)):
            raman_types['CALL(M,I)']+=1
        elif(re.findall("^NOP$",ins)):
            raman_types['NOP']+=1
        elif(re.findall("^IDLE$",ins)):
            raman_types['IDLE']+=1
        elif(re.findall("^FINISH$",ins)):
            raman_types['FINISH']+=1
        elif(re.findall("^[ ]?[0-9,A-F]?[0-9,A-F]?[0-9,A-F]?[0-9,A-F]?[ ]?$",ins.split("=")[-1]) and (re.findall("[^#]",ins))):
            raman_types['UREG = immediate data']+=1
        elif(re.findall("POP",ins.split("=")[-1])):
            raman_types['UREG = POP PCSTK']+=1
        elif(re.findall("DM[ ]?[(][ ]?I[0-7][ ]?,[ ]?M[0-7][ ]?[)][ ]?=[ ]?FADDR[ ]?$",ins)):
            raman_types['DM = UREG']+=1
        elif(re.findall("DM[ ]?[(][ ]?I[0-7][ ]?,[ ]?M[0-7][ ]?[)][ ]?=[ ]?DADDR[ ]?$",ins)):
            raman_types['DM = UREG']+=1
        elif(re.findall("DM[ ]?[(][ ]?I[0-7][ ]?,[ ]?M[0-7][ ]?[)][ ]?=[ ]?PC$[ ]?",ins)):
            raman_types['DM = UREG']+=1
        elif(re.findall("DM[ ]?[(][ ]?I[0-7][ ]?,[ ]?M[0-7][ ]?[)][ ]?=[ ]?PCSTKP[ ]?$",ins)):
            raman_types['DM = UREG']+=1
        elif(re.findall("DM[ ]?[(][ ]?I[0-7][ ]?,[ ]?M[0-7][ ]?[)][ ]?=[ ]?STKY[ ]?$",ins)):
            raman_types['DM = UREG']+=1
        elif(re.findall("^[I]?[F]?[ ]?[N]?[O]?[T]?[ ]?[A]?[V]?[A]?[C]?[M]?[V]?[M]?[S]?[S]?[V]?[S]?[Z]?[E]?[Q]?[N]?[E]?[L]?[E]?[L]?[T]?[G]?[E]?[G]?[T]?[R]?[I]?[M]?[A]?[S]?[T]?[A]?[T]?[P]?[C]?[S]?[T]?[K]?[M]?[O]?[D]?[E]?[0-9]?[0-9]?[ ]?=[ ]?FADDR[ ]?$",ins)):
            raman_types['UREG = UREG']+=1
        elif(re.findall("^[I]?[F]?[ ]?[N]?[O]?[T]?[ ]?[A]?[V]?[A]?[C]?[M]?[V]?[M]?[S]?[S]?[V]?[S]?[Z]?[E]?[Q]?[N]?[E]?[L]?[E]?[L]?[T]?[G]?[E]?[G]?[T]?[R]?[I]?[M]?[A]?[S]?[T]?[A]?[T]?[P]?[C]?[S]?[T]?[K]?[M]?[O]?[D]?[E]?[0-9]?[0-9]?[ ]?=[ ]?DADDR[ ]?$",ins)):
            raman_types['UREG = UREG']+=1
        elif(re.findall("^[I]?[F]?[ ]?[N]?[O]?[T]?[ ]?[A]?[V]?[A]?[C]?[M]?[V]?[M]?[S]?[S]?[V]?[S]?[Z]?[E]?[Q]?[N]?[E]?[L]?[E]?[L]?[T]?[G]?[E]?[G]?[T]?[R]?[I]?[M]?[A]?[S]?[T]?[A]?[T]?[P]?[C]?[S]?[T]?[K]?[M]?[O]?[D]?[E]?[0-9]?[0-9]?[ ]?=[ ]?PC[ ]?$",ins)):
            raman_types['UREG = UREG']+=1
        elif(re.findall("^[I]?[F]?[ ]?[N]?[O]?[T]?[ ]?[A]?[V]?[A]?[C]?[M]?[V]?[M]?[S]?[S]?[V]?[S]?[Z]?[E]?[Q]?[N]?[E]?[L]?[E]?[L]?[T]?[G]?[E]?[G]?[T]?[R]?[I]?[M]?[A]?[S]?[T]?[A]?[T]?[P]?[C]?[S]?[T]?[K]?[M]?[O]?[D]?[E]?[0-9]?[0-9]?[ ]?=[ ]?PCSTKP[ ]?$",ins)):
            raman_types['UREG = UREG']+=1
        elif(re.findall("^[I]?[F]?[ ]?[N]?[O]?[T]?[ ]?[A]?[V]?[A]?[C]?[M]?[V]?[M]?[S]?[S]?[V]?[S]?[Z]?[E]?[Q]?[N]?[E]?[L]?[E]?[L]?[T]?[G]?[E]?[G]?[T]?[R]?[I]?[M]?[A]?[S]?[T]?[A]?[T]?[P]?[C]?[S]?[T]?[K]?[M]?[O]?[D]?[E]?[0-9]?[0-9]?[ ]?=[ ]?STKY[ ]?$",ins)):
            raman_types['UREG = UREG']+=1
        if(re.findall("^IF",ins)):
            if(re.findall("NOT",ins)):
                if(re.findall("AV",ins)):
                    raman_types['NOT_AV']+=1
                elif(re.findall("MV",ins)):
                    raman_types['NOT_MV']+=1
                elif(re.findall("AC",ins)):
                    raman_types['NOT_AC']+=1
                elif(re.findall("SZ",ins)):
                    raman_types['NOT_SZ']+=1
                elif(re.findall("MS",ins)):
                    raman_types['NOT_MS']+=1
                elif(re.findall("SV",ins)):
                    raman_types['NOT_SV']+=1
            else:
                if(re.findall("AV",ins)):
                    raman_types['AV']+=1
                elif(re.findall("MV",ins)):
                    raman_types['MV']+=1
                elif(re.findall("AC",ins)):
                    raman_types['AC']+=1
                elif(re.findall("SZ",ins)):
                    raman_types['SZ']+=1
                elif(re.findall("MS",ins)):
                    raman_types['MS']+=1
                elif(re.findall("SV",ins)):
                    raman_types['SV']+=1
                elif(re.findall("NE",ins)):
                    raman_types['NE']+=1
                elif(re.findall("GE",ins)):
                    raman_types['GE']+=1
                elif(re.findall("GT",ins)):
                    raman_types['GT']+=1
                elif(re.findall("EQ",ins)):
                    raman_types['EQ']+=1
                elif(re.findall("LE",ins)):
                    raman_types['LE']+=1
                elif(re.findall("LT",ins)):
                    raman_types['LT']+=1
                elif(re.findall("FOREVER",ins)):
                    raman_types['FOREVER']+=1
        if((tem1==ins.split("=")[-1]) or (tem2==ins.split("=")[-1]) or (tem3==ins.split("=")[-1]) or (tem4==ins.split("=")[-1]) or (tem5==ins.split("=")[-1]) or (tem6==ins.split("=")[-1]) or (tem7==ins.split("=")[-1]) or (tem8==ins.split("=")[-1])):
            if ins.strip():
                raman_types['UREG to UREG bypasses']+=1
        if(re.findall("DM",ins)):
            tp="a"
        else:
            temp1=ins.split("=")[0]
            tem1=temp1.split("C")[-1]
            tem2=temp1.split("V")[-1]
            tem3=temp1.split("S")[-1]
            tem4=temp1.split("Z")[-1]
            tem5=temp1.split("E")[-1]
            tem6=temp1.split("T")[-1]
            tem7=temp1.split("FOREVER")[-1]
            tem8=temp1.split("Q")[-1]
        if(re.findall("PUSH",ins) or re.findall("POP",ins)):
            temps1="STKY"
        elif(re.findall("STKY",ins.split("=")[-1])):
            temps2="STKY"
            if(temps1==temps2):
                raman_types['Sticky bypasses']+=1
                temps1="ab"
                temps2="cd"
        else:
            temps1="ab"
            temps2="cd"
        if(re.findall("PUSH",ins) or re.findall("POP",ins)):
            temppc1="PCSTKP"
        elif(re.findall("PCSTKP",ins.split("=")[-1])):
            temppc2="PCSTKP"
            if(temppc1==temppc2):
                raman_types['PCSTK pointer bypasses']+=1
                temppc1="ab"
                temppc2="cd"
        else:
            temppc1="ab"
            temppc2="cd"
        if((re.findall("MR",ins)) or (re.findall("[*]",ins)) or (re.findall("[+]",ins)) or (re.findall("[-]",ins)) or (re.findall("COMP",ins)) or (re.findall("MIN",ins)) or (re.findall("MAX",ins)) or (re.findall("ABS",ins)) or (re.findall("AND",ins)) or (re.findall("OR",ins)) or (re.findall("NOT",ins)) or (re.findall("BY",ins)) or (re.findall("LEFT",ins))):
            tempcpt1="ASTAT"
        elif(re.findall("ASTAT",ins.split("=")[-1])):
            tempcpt2="ASTAT"
            if(tempcpt1==tempcpt2):
                raman_types['ASTAT bypasses']+=1
                tempcpt1="ab"
                tempcpt2="cd"
        else:
            tempcpt1="ab"
            tempcpt2="cd"
        if(re.findall("DM",ins.split("=")[0])):
            temp1=(re.findall("I[0-7]",ins.split("=")[0]))
        elif(re.findall("DM",ins.split("=")[-1])):
            temp2=(re.findall("I[0-7]",ins.split("=")[-1]))
            if(temp1==temp2):
                raman_types['DM bypass']+=1
                temp1="ab"
                temp2="cd"
        else:
            temp1="ab"
            temp2="cd"
        if(re.findall("DM",ins.split("=")[0])):
            ts="b"
        elif(re.findall("I[0-7]",ins.split("=")[0])):
            temp11=(re.findall("I[0-7]",ins.split("=")[0]))
        elif(re.findall("DM",ins.split("=")[-1])):
            temp22=(re.findall("I[0-7]",ins.split("=")[-1]))
            if(temp11==temp22):
                raman_types['I to DM bypass']+=1
                temp11="an"
                temp22="cb"
        else:
            temp11="an"
            temp22="cb"
        if(re.findall("DM",ins.split("=")[0])):
            te="a"
        elif(re.findall("M[0-7]",ins.split("=")[0])):
            temp3=(re.findall("M[0-7]",ins.split("=")[0]))
        elif(re.findall("DM",ins.split("=")[-1])):
            temp4=(re.findall("M[0-7]",ins.split("=")[-1]))
            if(temp3==temp4):
                raman_types['M to DM bypass']+=1
                temp3="b"
                temp4="d"
        else:
            temp3="b"
            temp4="d"
        if(re.findall("ASTAT$",ins.split("=")[0])):
            raman_types['ASTAT write']+=1
        elif(re.findall("^ASTAT",ins.split("=")[-1])):
            raman_types['ASTAT read']+=1
        if(re.findall("MODE1$",ins.split("=")[0])):
            raman_types['MODE1 write']+=1
        elif(re.findall("^MODE1",ins.split("=")[-1])):
            raman_types['MODE1 read']+=1
        if(re.findall("PCSTK$",ins.split("=")[0])):
            raman_types['PCSTK write']+=1
        elif(re.findall("^PCSTK",ins.split("=")[-1])):
            raman_types['PCSTK read']+=1
        if(re.findall("FADDR$",ins.split("=")[-1])):
            raman_types['FADDR read']+=1
        if(re.findall("DADDR$",ins.split("=")[-1])):
            raman_types['DADDR read']+=1
        if(re.findall("STKY$",ins.split("=")[-1])):
            raman_types['STKY read']+=1
        if(re.findall("PC$",ins.split("=")[-1])):
            raman_types['PC read']+=1
        if(re.findall("PCSTKP$",ins.split("=")[-1])):
            raman_types['PCSTKP read']+=1

        if(re.findall("R0$",ins.split("=")[0])):
            raman_types['R0 write']+=1
        elif(re.findall("^R0$",ins.split("=")[-1])):
            raman_types['R0 read']+=1
        if(re.findall("R1$",ins.split("=")[0])):
            raman_types['R1 write']+=1
        elif(re.findall("^R1$",ins.split("=")[-1])):
            raman_types['R1 read']+=1
        if(re.findall("R2$",ins.split("=")[0])):
            raman_types['R2 write']+=1
        elif(re.findall("^R2$",ins.split("=")[-1])):
            raman_types['R2 read']+=1
        if(re.findall("R3$",ins.split("=")[0])):
            raman_types['R3 write']+=1
        elif(re.findall("^R3$",ins.split("=")[-1])):
            raman_types['R3 read']+=1
        if(re.findall("R4$",ins.split("=")[0])):
            raman_types['R4 write']+=1
        elif(re.findall("^R4$",ins.split("=")[-1])):
            raman_types['R4 read']+=1
        if(re.findall("R5$",ins.split("=")[0])):
            raman_types['R5 write']+=1
        elif(re.findall("^R5$",ins.split("=")[-1])):
            raman_types['R5 read']+=1
        if(re.findall("R6$",ins.split("=")[0])):
            raman_types['R6 write']+=1
        elif(re.findall("^R6$",ins.split("=")[-1])):
            raman_types['R6 read']+=1
        if(re.findall("R7$",ins.split("=")[0])):
            raman_types['R7 write']+=1
        elif(re.findall("^R7$",ins.split("=")[-1])):
            raman_types['R7 read']+=1
        if(re.findall("R8$",ins.split("=")[0])):
            raman_types['R8 write']+=1
        elif(re.findall("^R8$",ins.split("=")[-1])):
            raman_types['R8 read']+=1
        if(re.findall("R9$",ins.split("=")[0])):
            raman_types['R9 write']+=1
        elif(re.findall("^R9$",ins.split("=")[-1])):
            raman_types['R9 read']+=1
        if(re.findall("R10$",ins.split("=")[0])):
            raman_types['R10 write']+=1
        elif(re.findall("^R10$",ins.split("=")[-1])):
            raman_types['R10 read']+=1
        if(re.findall("R11$",ins.split("=")[0])):
            raman_types['R11 write']+=1
        elif(re.findall("^R11$",ins.split("=")[-1])):
            raman_types['R11 read']+=1
        if(re.findall("R12$",ins.split("=")[0])):
            raman_types['R12 write']+=1
        elif(re.findall("^R12$",ins.split("=")[-1])):
            raman_types['R12 read']+=1
        if(re.findall("R13$",ins.split("=")[0])):
            raman_types['R13 write']+=1
        elif(re.findall("^R13$",ins.split("=")[-1])):
            raman_types['R13 read']+=1
        if(re.findall("R14$",ins.split("=")[0])):
            raman_types['R14 write']+=1
        elif(re.findall("^R14$",ins.split("=")[-1])):
            raman_types['R14 read']+=1
        if(re.findall("R15$",ins.split("=")[0])):
            raman_types['R15 write']+=1
        elif(re.findall("^R15$",ins.split("=")[-1])):
            raman_types['R15 read']+=1
        
        if(re.findall("I0$",ins.split("=")[0])):
            raman_types['I0 write']+=1
        elif(re.findall("^I0$",ins.split("=")[-1])):
            raman_types['I0 read']+=1
        if(re.findall("I1$",ins.split("=")[0])):
            raman_types['I1 write']+=1
        elif(re.findall("^I1$",ins.split("=")[-1])):
            raman_types['I1 read']+=1
        if(re.findall("I2$",ins.split("=")[0])):
            raman_types['I2 write']+=1
        elif(re.findall("^I2$",ins.split("=")[-1])):
            raman_types['I2 read']+=1
        if(re.findall("I3$",ins.split("=")[0])):
            raman_types['I3 write']+=1
        elif(re.findall("^I3$",ins.split("=")[-1])):
            raman_types['I3 read']+=1
        if(re.findall("I4$",ins.split("=")[0])):
            raman_types['I4 write']+=1
        elif(re.findall("^I4$",ins.split("=")[-1])):
            raman_types['I4 read']+=1
        if(re.findall("I5$",ins.split("=")[0])):
            raman_types['I5 write']+=1
        elif(re.findall("^I5$",ins.split("=")[-1])):
            raman_types['I5 read']+=1
        if(re.findall("I6$",ins.split("=")[0])):
            raman_types['I6 write']+=1
        elif(re.findall("^I6$",ins.split("=")[-1])):
            raman_types['I6 read']+=1
        if(re.findall("I7$",ins.split("=")[0])):
            raman_types['I7 write']+=1
        elif(re.findall("^I7$",ins.split("=")[-1])):
            raman_types['I7 read']+=1
        if(re.findall("I8$",ins.split("=")[0])):
            raman_types['I8 write']+=1
        elif(re.findall("^I8$",ins.split("=")[-1])):
            raman_types['I8 read']+=1
        if(re.findall("I9$",ins.split("=")[0])):
            raman_types['I9 write']+=1
        elif(re.findall("^I9$",ins.split("=")[-1])):
            raman_types['I9 read']+=1
        if(re.findall("I10$",ins.split("=")[0])):
            raman_types['I10 write']+=1
        elif(re.findall("^I10$",ins.split("=")[-1])):
            raman_types['I10 read']+=1
        if(re.findall("I11$",ins.split("=")[0])):
            raman_types['I11 write']+=1
        elif(re.findall("^I11$",ins.split("=")[-1])):
            raman_types['I11 read']+=1
        if(re.findall("I12$",ins.split("=")[0])):
            raman_types['I12 write']+=1
        elif(re.findall("^I12$",ins.split("=")[-1])):
            raman_types['I12 read']+=1
        if(re.findall("I13$",ins.split("=")[0])):
            raman_types['I13 write']+=1
        elif(re.findall("^I13$",ins.split("=")[-1])):
            raman_types['I13 read']+=1
        if(re.findall("I14$",ins.split("=")[0])):
            raman_types['I14 write']+=1
        elif(re.findall("^I14$",ins.split("=")[-1])):
            raman_types['I14 read']+=1
        if(re.findall("I15$",ins.split("=")[0])):
            raman_types['I15 write']+=1
        elif(re.findall("^I15$",ins.split("=")[-1])):
            raman_types['I15 read']+=1
        if(re.findall("M0$",ins.split("=")[0])):
            raman_types['M0 write']+=1
        elif(re.findall("^M0$",ins.split("=")[-1])):
            raman_types['M0 read']+=1
        if(re.findall("M1$",ins.split("=")[0])):
            raman_types['M1 write']+=1
        elif(re.findall("^M1$",ins.split("=")[-1])):
            raman_types['M1 read']+=1
        if(re.findall("M2$",ins.split("=")[0])):
            raman_types['M2 write']+=1
        elif(re.findall("^M2$",ins.split("=")[-1])):
            raman_types['M2 read']+=1
        if(re.findall("M3$",ins.split("=")[0])):
            raman_types['M3 write']+=1
        elif(re.findall("^M3$",ins.split("=")[-1])):
            raman_types['M3 read']+=1
        if(re.findall("M4$",ins.split("=")[0])):
            raman_types['M4 write']+=1
        elif(re.findall("^M4$",ins.split("=")[-1])):
            raman_types['M4 read']+=1
        if(re.findall("M5$",ins.split("=")[0])):
            raman_types['M5 write']+=1
        elif(re.findall("^M5$",ins.split("=")[-1])):
            raman_types['M5 read']+=1
        if(re.findall("M6$",ins.split("=")[0])):
            raman_types['M6 write']+=1
        elif(re.findall("^M6$",ins.split("=")[-1])):
            raman_types['M6 read']+=1
        if(re.findall("M7$",ins.split("=")[0])):
            raman_types['M7 write']+=1
        elif(re.findall("^M7$",ins.split("=")[-1])):
            raman_types['M7 read']+=1
        if(re.findall("M8$",ins.split("=")[0])):
            raman_types['M8 write']+=1
        elif(re.findall("^M8$",ins.split("=")[-1])):
            raman_types['M8 read']+=1
        if(re.findall("M9$",ins.split("=")[0])):
            raman_types['M9 write']+=1
        elif(re.findall("^M9$",ins.split("=")[-1])):
            raman_types['M9 read']+=1
        if(re.findall("M10$",ins.split("=")[0])):
            raman_types['M10 write']+=1
        elif(re.findall("^M10$",ins.split("=")[-1])):
            raman_types['M10 read']+=1
        if(re.findall("M11$",ins.split("=")[0])):
            raman_types['M11 write']+=1
        elif(re.findall("^M11$",ins.split("=")[-1])):
            raman_types['M11 read']+=1
        if(re.findall("M12$",ins.split("=")[0])):
            raman_types['M12 write']+=1
        elif(re.findall("^M12$",ins.split("=")[-1])):
            raman_types['M12 read']+=1
        if(re.findall("M13$",ins.split("=")[0])):
            raman_types['M13 write']+=1
        elif(re.findall("^M13$",ins.split("=")[-1])):
            raman_types['M13 read']+=1
        if(re.findall("M14$",ins.split("=")[0])):
            raman_types['M14 write']+=1
        elif(re.findall("^M14$",ins.split("=")[-1])):
            raman_types['M14 read']+=1
        if(re.findall("M15$",ins.split("=")[0])):
            raman_types['M15 write']+=1
        elif(re.findall("^M15$",ins.split("=")[-1])):
            raman_types['M15 read']+=1

        raman_types['UREG reads']=raman_types['UREG = UREG']+raman_types['DM = UREG']+raman_types['PUSH PCSTK = UREG']
        raman_types['UREG writes']=raman_types['UREG = UREG']+raman_types['UREG = DM']+raman_types['UREG = POP PCSTK']+raman_types['UREG = immediate data']
        raman_x=raman_types['MODIFY(I,M)']+raman_types['UREG = UREG']+raman_types['DM = UREG']+raman_types['UREG = DM']+raman_types['RTS']+raman_types['IDLE']+raman_types['NOP']+raman_types['FINISH']+raman_types['PUSH PCSTK = UREG']+raman_types['UREG = POP PCSTK']+raman_types['UREG = immediate data']+raman_types['JUMP(M,I)']+raman_types['CALL(M,I)']
        #print(raman_i,' ',raman_j)
        #raman_z=(raman_x/(raman_i-raman_j))*100
        raman_types['Bypasses']=raman_types['UREG to UREG bypasses']+raman_types['Sticky bypasses']+raman_types['PCSTK pointer bypasses']+raman_types['ASTAT bypasses']+raman_types['DM bypass']+raman_types['I to DM bypass']+raman_types['M to DM bypass']
        #raman_y=raman_i-raman_j-raman_types['Bypasses']
    return raman_j

def raman_main(path):
    global raman_i,raman_m,raman_j,raman_x,raman_y,raman_z
    #path=input("Enter path to directory containing instruction files : ")
    folders=os.listdir(path)
    for folder in folders:
        files_list=os.listdir(f'{path}/{folder}')
        for file in files_list:
            raman_m+=1
            with open(path+"\\"+folder+'\\'+file) as f:
                for ins in f:
                    ins=ins.split('#')[0]
                    if ins.strip():
                        raman_i+=1
                    ins=re.sub("\s*","",ins)
                    ins=ins.upper()
                    raman_j=raman_cov(ins)
    
    print('='*50)
    print('\nRaman coverage')
    print("Number of instructions = ",raman_i-raman_j)
    #print(raman_j)

    with open("raman_coverage.csv","w",newline='') as csvF:
        wobj=csv.writer(csvF,delimiter=',')
        wobj.writerow(['Total Files',raman_m])
        wobj.writerow(['Total Instructions',raman_i-raman_j])
        wobj.writerow(['PS Instructions',raman_x])
        #wobj.writerow(['Percentage of PS Instructions',raman_z])
        #wobj.writerow(['',''])
        wobj.writerow(['Instructions','Count'])
        #wobj.writerow(['',''])
        for ins in raman_types.keys():
            wobj.writerow([ins,raman_types[ins]])


#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
#                                           Arundhathy coverage
#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

def arundhathy_cov(path):
    #os.chdir(path)
    total_count = 0
    count_ashift = 0
    count_rot = 0
    count_leftz = 0
    count_lefto = 0
    
    folders=os.listdir(path)
    for folder in folders:
        files_list=os.listdir(path+'/'+folder)
        for f in files_list:
            if f.endswith(".txt"):
                outfile = open(path+'/'+folder+'/'+f, 'r')
                data = outfile.read()
                data = data.upper()
                match_ashift = re.findall("R[0-9]+[ ]?=[ ]?ASHIFT[ ]?R[0-9]+[ ]?BY[ ]?R[0-9]+[ ]?",data)
                match_rot = re.findall("R[0-9]+[ ]?=[ ]?ROT[ ]?R[0-9]+[ ]?BY[ ]?R[0-9]+[ ]?",data)
                match_leftz = re.findall("R[0-9]+[ ]?=[ ]?LEFTZ[ ]?R[0-9]+[ ]?",data)
                match_lefto = re.findall("R[0-9]+[ ]?=[ ]?LEFTO[ ]?R[0-9]+[ ]?",data)
                if(match_ashift):
                    count_ashift+=len(match_ashift)
                if(match_rot):
                    count_rot+=len(match_rot)
                if(match_leftz):
                    count_leftz+=len(match_leftz)
                if(match_lefto):
                    count_lefto+=len(match_lefto)
                outfile.close()
                total_count+=1
                outfile.close()
                #if outfile.closed:
                #    print('closed')

    print('='*50)
    print('\nArundhathy Coverage')
    print("Number of files covered:", total_count)
    print("\nRx = ASHIFT Rx BY Ry :", count_ashift)
    print("Rx = ROT Rx BY Ry :", count_rot)
    print("Rx = LEFTZ Rx :", count_leftz)
    print("Rx = LEFTO Rx :", count_lefto)



path=input("Enter path to directory containing instruction files : ")
ashwinpradeep_main(path)
raman_main(path)
arundhathy_cov(path)
