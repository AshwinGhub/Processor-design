import re

string={'MR = MR + Rx * Ry UUI': 0, 'MR = MR + Rx * Ry UUF': 0, 'MR = MR + Rx * Ry UUFR': 0, 'MR = MR + Rx * Ry SUI': 0, 'MR = MR + Rx * Ry SUF': 0, 'MR = MR + Rx * Ry SUFR': 0, 'MR = MR + Rx * Ry USI': 0, 'MR = MR + Rx * Ry USF': 0, 'MR = MR + Rx * Ry USFR': 0, 'MR = MR + Rx * Ry SSI': 0, 'MR = MR + Rx * Ry SSF': 0, 'MR = MR + Rx * Ry SSFR': 0
        }

s={}
for key in string.keys():
    s[key.replace("MR + Rx * Ry","SAT MR")]=string[key]
print(s)
