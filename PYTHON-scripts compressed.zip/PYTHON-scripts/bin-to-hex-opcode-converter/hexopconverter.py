'''
l=[3,6,2,5,1]
for i in range(len(l)-1):
    for j in range(1,len(l)-i):
        if l[j]<l[j-1]:
            l[j],l[j-1]=l[j-1],l[j]
print(l)
print(l[3]) # 4th smallest
print(l[-4])    # 4th largest
'''
pmpath='C:\\Users\\Ashwin-Pradeep\\Desktop\\Project-Final-Year\\GIT-repo\\myCreations_9thJune\\memory_files\\pm\\PASSED\\AshwintestsALU\\11_pm.txt'
pmhex='C:\\Users\\Ashwin-Pradeep\\Desktop\\Project-Final-Year\\GIT-repo\\local-repo-copy\\pm_file.txt'
with open(pmpath,'r') as f:
    fw=open(pmhex,'w')
    for line in f:
        h=str(hex(int(line,2)).replace('0x',''))
        for i in range(8-len(h)):
            h='0'+h
        fw.write(h)
        fw.write('\n')
    fw.close()